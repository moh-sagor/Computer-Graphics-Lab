# AmusementParkGraphics

YouTube Video Link: https://youtu.be/WoYJ2nEEFU8

My project is like an amusement park where a child can enjoy some rides. Here is some instruction to run the project.

Girls Movement:
The girl will move with the "up, down, left, and right" arrow key.

Swing (Dolna):
The girl will get onto the swing by pressing "u", will enjoy and can get down from the swing by pressing "d".

Glider (Up-Down Ride):
The girl will get onto the glider by pressing "g", will get down by pressing "j" and glider will work by pressing "h" and "l".

Slide: 
The girl will climb the slide by pressing "o". If "o" is press 1-time girl will climb 1st stair if press "o" again then it will climb the 2nd step and by 4th pressing the girl will slide down.

Whirligig (Nagordola):
If "w" is pressed girl will get onto the ride. It will round 2 times and after that the girl will automatically get down from it. 

Bench:
The girl will sit on the bench by pressing "r" and girl will stand up by pressing "s".

Boat:
The girl will get onto the boat and boat will move by pressing "b" and get down from the boat by pressing "c" when it’s in the middle(almost) of the river.
